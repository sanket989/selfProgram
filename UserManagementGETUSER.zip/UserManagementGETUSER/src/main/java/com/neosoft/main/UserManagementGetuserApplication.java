package com.neosoft.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementGetuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementGetuserApplication.class, args);
	}

}
