package com.neosoft.mainServicei;

import java.util.List;

import com.neosoft.main.entity.UserData;

public interface userServiceI {
	public List<UserData> ListOFUSER();
	public UserData SingleResult(String id);
	

}