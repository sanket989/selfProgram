package com.neosoft.main.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neosoft.main.entity.UserData;
import com.neosoft.main.serviceI.UserServiceI;


@RestController
@RequestMapping("User-management")
public class userController {
	
	@Autowired
	UserServiceI userser;
	
	
	private static final Logger log = LoggerFactory.getLogger(userController.class);
	
	@PutMapping("/updateUser")
	private ResponseEntity<Object> updateUser(@RequestBody UserData userupdate)
	{
		
		UserData user=userser.Edituser(userupdate);
		
		if(user!=null)
		{
			return new ResponseEntity<Object>(user,HttpStatus.OK);
					
		}
		return new ResponseEntity<Object>("USER"+userupdate.getId()+"DOES NOT EXITS!",HttpStatus.NOT_FOUND);
		
	}
	@DeleteMapping("/deleteUser/{id}")
    public ResponseEntity<String> deletedata(@PathVariable ("id") String id) 
    {
  	 
  	 log.info("******************************"+"DELETE DATA"+"**********************");
  	 

	
  	 String resMessage=userser.DeleteUSER(id);
  
		if(resMessage !=null)
	{
			
			
			return new ResponseEntity<String>(resMessage,HttpStatus.OK);			
	 
		
		}
		return new ResponseEntity<String>("USER"+id+"DOES NOT EXITS!!",HttpStatus.NOT_FOUND);
		 
  	 
  	
   }
	


}
