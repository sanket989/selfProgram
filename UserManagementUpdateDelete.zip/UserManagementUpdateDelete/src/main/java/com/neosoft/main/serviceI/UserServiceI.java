package com.neosoft.main.serviceI;

import com.neosoft.main.entity.UserData;

public interface UserServiceI {
	public UserData Edituser(UserData  updateuser);
	public String DeleteUSER(String id);

}
