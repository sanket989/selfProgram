package com.neosoft.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementUpdateDeleteApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementUpdateDeleteApplication.class, args);
	}

}
