package com.neosoft.main;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neosoft.main.entity.UserData;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserManagementUpdateDeleteApplicationTests {

	@Test
	void contextLoads() {
	}
	
	 @Autowired
	    private TestRestTemplate restTemplate;
		 
		 protected MockMvc mvc;
		 
		 private String getRootUrl() {
		        return "http://localhost:8084/User-management";
		    }
		// FOR READING AND WRITTING JSON
		    public String mapToJson(Object obj) throws JsonProcessingException {
		        ObjectMapper objectMapper = new ObjectMapper();
		        return objectMapper.writeValueAsString(obj);
		     }

		    
			//TEST FOR UPDATE USER
		     @Test
		     public void testupdateUser() {
		         String id = "60cb2b4d935399301ee67693";
		         UserData user = restTemplate.getForObject(getRootUrl() + "/updateUser/" + id,UserData.class);
		         
		         restTemplate.put(getRootUrl() + "/updateUser/" + id, user);
		         UserData updateduser = restTemplate.getForObject(getRootUrl() + "/updateUser/" + id, UserData.class);
		         assertNotNull(updateduser);
		     }
		     //TEST FOR DELETE USER
		     @Test
		     public void testdeletedata() {
		    	 String id = "60cb2b4d935399301ee67693";
		          UserData user = restTemplate.getForObject(getRootUrl() + "/deleteUser/" + id,UserData.class);
		          assertNotNull(user);
		          restTemplate.delete(getRootUrl() + "/user/" + id);
		          try {
		               user = restTemplate.getForObject(getRootUrl() + "/deleteUser/" + id, UserData.class);
		          } catch (final HttpClientErrorException e) {
		               assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		          }
		     }

}
