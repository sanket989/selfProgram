package com.neosoft.main.serviceI;

import com.neosoft.main.entity.UserData;

public interface userServiceI {
	public String SaveUser(UserData userdata);
	

}
