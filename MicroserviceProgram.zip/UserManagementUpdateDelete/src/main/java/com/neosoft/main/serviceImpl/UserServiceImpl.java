package com.neosoft.main.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neosoft.main.entity.UserData;
import com.neosoft.main.repository.userRepository;
import com.neosoft.main.serviceI.UserServiceI;

@Service
public class UserServiceImpl implements UserServiceI{

	@Autowired
	userRepository repo;
	
	@Override
	public UserData Edituser(UserData updateuser) {
		// TODO Auto-generated method stub
		
		 Optional<UserData>updata=repo.findById(updateuser.getId());
         if(updata.isPresent())
         {
        	 repo.save(updateuser);
        	 return updateuser; 
         }
		return null;
		
	}

	@Override
	public String DeleteUSER(String id) {
		
		Optional<UserData>deluser=repo.findById(id);	
		 
		 if(deluser.isPresent()) {
		
		
		repo.deleteById(id);
		
		
		 return "USER"+id+"REMOVE RECORD!";

			}
		return null;
	}
}
