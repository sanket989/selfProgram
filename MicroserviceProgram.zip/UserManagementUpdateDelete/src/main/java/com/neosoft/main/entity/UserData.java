package com.neosoft.main.entity;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;



import lombok.Getter;
import lombok.Setter;
//@Document(collation = "USERDATA")
public class UserData {
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Id
	@Setter @Getter
	private String id;
	@NotBlank(message = "USERFIRSTNAME is Missing")
	@Size(max = 16)
	
	private String userFirstName;
	@NotBlank(message = "USERLASTNAME is Missing")
	@Size(max = 16)
	
	private String userLastName;

	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserMobileNo() {
		return userMobileNo;
	}
	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}
	public String getUserEmailAddress() {
		return userEmailAddress;
	}
	public void setUserEmailAddress(String userEmailAddress) {
		this.userEmailAddress = userEmailAddress;
	}
	public String getUserpincode() {
		return userpincode;
	}
	public void setUserpincode(String userpincode) {
		this.userpincode = userpincode;
	}
	@NotBlank(message = "USER ADDRESS is Missing")
	@Size(max = 50)
	
	private String userAddress;
	@NotBlank(message = "USER MOBILE NO is Missing")
	@Size(max = 16)
	
	private String userMobileNo;

	@Email(message = "Email Address should be valid ")
	private String userEmailAddress;
	@NotBlank(message = "USER PINCODE is Missing")
	@Size(max = 16)
	
	private String userpincode;

}
