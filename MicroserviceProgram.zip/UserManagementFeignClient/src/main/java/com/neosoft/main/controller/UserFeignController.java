package com.neosoft.main.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neosoft.main.config.UserFeignClient;
import com.neosoft.main.model.UserData;


@RestController
@RequestMapping("/User-management")
public class UserFeignController {
	
	
	
	@Autowired
	private UserFeignClient userFeign;
	
		private static final Logger log = LoggerFactory.getLogger(UserFeignController.class);

	@GetMapping("/GETAllUSER")
	public ResponseEntity<List<UserData>> getAlluser()
	{
		log.info("***************************"+" GET ALL DATA"+"******************");
		
List<UserData> user=userFeign.ListOFUSER();
			

return new ResponseEntity<List<UserData>>(user,HttpStatus.OK);
		}
	@GetMapping("/get/{id}")
	public ResponseEntity<UserData> getUser(@PathVariable("id") String id)
	{
		log.info("***************************"+"Specific DATA"+"******************");
		
		Optional<UserData> Data = userFeign.getUser(id);

		  if (Data.isPresent()) {
		    return new ResponseEntity<>(Data.get(), HttpStatus.OK);
		  } else {
		    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		  }
}
	
	
	@PostMapping("/Add_user")
	public ResponseEntity<String> Adduser(@Valid @RequestBody UserData user,BindingResult result)
	{
     log.info("***************************"+"INSIDE DATA"+"******************");
		
		
		String respMessage;
		HttpStatus httpstatus;
		if(result.hasErrors())
		{
			respMessage="invalid Employee"+result.getFieldError();
			return new ResponseEntity<String>(respMessage,HttpStatus.BAD_REQUEST);
		}
		
		respMessage=userFeign.Adduser(user);
		
		httpstatus=HttpStatus.CREATED;
		
		return new ResponseEntity<String> (respMessage,httpstatus);
		
	}
	
	
     @PutMapping("/updateUser")
     private ResponseEntity<Object> updateUser(@RequestBody UserData userupdate)
 	{
 		
 		UserData user=userFeign.updateUser(userupdate);
 		
 		if(user!=null)
 		{
 			return new ResponseEntity<Object>(user,HttpStatus.OK);
 					
 		}
 		return new ResponseEntity<Object>("USER"+userupdate.getId()+"DOES NOT EXITS!",HttpStatus.NOT_FOUND);
 		
 	}
	
     @DeleteMapping("/deleteUser/{id}")
     public ResponseEntity<String> deletedata(@PathVariable ("id") String id) 
     {
   	 
   	 log.info("******************************"+"DELETE DATA"+"**********************");
   	 

 	
   	 String resMessage=userFeign.deletedata(id);
   
 		if(resMessage !=null)
 	{
			return new ResponseEntity<String>(resMessage,HttpStatus.OK);			
			 
			
		}
		return new ResponseEntity<String>("USER"+id+"DOES NOT EXITS!!",HttpStatus.NOT_FOUND);
		 
  	 
  	
   }
	

	
}
