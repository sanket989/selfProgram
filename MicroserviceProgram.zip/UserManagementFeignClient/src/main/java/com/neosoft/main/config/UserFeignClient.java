package com.neosoft.main.config;

import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.neosoft.main.model.UserData;
// for getting data
//@FeignClient("user-get")
//for post data
@FeignClient("user-add")
// for update and delete data
//@FeignClient("user-Update")
public interface UserFeignClient {
	
	@GetMapping("/User-management/GETAllUSER")
	List<UserData> ListOFUSER();

	@GetMapping("/User-management/get/{id}")
	Optional<UserData> getUser(@PathVariable String id);
	
	@PostMapping("/User-management/Add_user")
	String Adduser( @RequestBody UserData user);
	
	@PutMapping("User-management/updateUser")
	UserData updateUser(@RequestBody UserData  userupdate);
	
	@DeleteMapping("User-management/deleteUser/{id}")
	String deletedata(@PathVariable String id);
	
}
