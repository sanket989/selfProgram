package com.neosoft.main.serviceimpl;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import org.springframework.stereotype.Service;


import com.neosoft.main.entity.UserData;
import com.neosoft.main.repository.userRepository;
import com.neosoft.mainServicei.userServiceI;



@Service
public class userServiceImpl implements userServiceI {

	@Autowired
	userRepository userrepo;
	
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public List<UserData> ListOFUSER() {
		List<UserData>list=(List<UserData>) userrepo.findAll();
		return list;
	}
	/*
	 * @Override public UserData SingleResult(String id) { // TODO Auto-generated
	 * method stub Optional<UserData>user=userrepo.findById(id);
	 * if(user.isPresent()) { user.get(); } return null;
	 * 
	 * }
	 */
	@Override
	public UserData SingleResult(String id) {
		// TODO Auto-generated method stub
		return null;
	}


}
