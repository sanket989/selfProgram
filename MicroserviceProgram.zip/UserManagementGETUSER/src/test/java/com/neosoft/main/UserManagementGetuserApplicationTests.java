package com.neosoft.main;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neosoft.main.entity.UserData;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserManagementGetuserApplicationTests {

	@Test
	void contextLoads() {
		
	}

	 @Autowired
    private TestRestTemplate restTemplate;
	 
	 protected MockMvc mvc;
	
    private String getRootUrl() {
        return "http://localhost:8083/User-management";
    }
    // FOR READING AND WRITTING JSON
    public String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
     }

  //TEST FOR GET ALL EMPLOYEE
    @Test
    public void testgetAlluser() {
    HttpHeaders headers = new HttpHeaders();
       HttpEntity<String> entity = new HttpEntity<String>(null, headers);
       ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/GETAllUSER",
       HttpMethod.GET, entity, String.class);  
       assertNotNull(response.getBody());
   } 
    // TEST FOR GET SPECIFIC EMPLOYEE
    @Test
   public void testgetUser() {
       UserData data = restTemplate.getForObject(getRootUrl() + "/get/60cb2b4d935399301ee67693", UserData.class);
       System.out.println(data.getUserFirstName());
       assertNotNull(data);
   }



}
