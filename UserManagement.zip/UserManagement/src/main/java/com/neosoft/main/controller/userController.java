package com.neosoft.main.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neosoft.main.entity.UserData;
import com.neosoft.main.serviceI.userServiceI;

@RestController
@RequestMapping("User-management")
public class userController {
	
	@Autowired
	userServiceI userser;
	
	private static final Logger log = LoggerFactory.getLogger(userController.class);
	
	
	@PostMapping("/Add_user")
	public ResponseEntity<String> Adduser(@Valid @RequestBody UserData user,BindingResult result)
	{
     log.info("***************************"+"INSIDE DATA"+"******************");
		
		
		String respMessage;
		HttpStatus httpstatus;
		if(result.hasErrors())
		{
			respMessage="invalid Employee"+result.getFieldError();
			return new ResponseEntity<String>(respMessage,HttpStatus.BAD_REQUEST);
		}
		
		respMessage=userser.SaveUser(user);
		
		httpstatus=HttpStatus.CREATED;
		
		return new ResponseEntity<String> (respMessage,httpstatus);
		
	}


}
