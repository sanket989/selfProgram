package com.neosoft.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neosoft.main.entity.UserData;
import com.neosoft.main.repository.userRepository;
import com.neosoft.main.serviceI.userServiceI;
@Service
public class useServiceImpl implements userServiceI {

	@Autowired
	userRepository userrepo;
	@Override
	public String SaveUser(UserData userdata) {
		// TODO Auto-generated method stub
		userrepo.save(userdata);
		return  "USER SUCCESSFULLY INSERT";
	}

}
