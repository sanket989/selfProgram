package com.neosoft.main;

import org.junit.runner.RunWith;




import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;



import org.springframework.web.client.HttpClientErrorException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.neosoft.main.entity.UserData;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserManagementApplicationTests {
	 @Autowired
     private TestRestTemplate restTemplate;
	 
	 protected MockMvc mvc;
	
     private String getRootUrl() {
         return "http://localhost:8082/User-management";
     }


	@Test
	void contextLoads() {
	}
	
    // FOR READING AND WRITTING JSON
    public String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
     }


	 //TEST FOR ADD EMPLOYEE
    @Test
    public void testAdduser() throws Exception {
   	
        UserData user=new UserData();
        user.setId("user010");
        user.setUserFirstName("sanket");
        user.setUserLastName("asati");
        user.setUserMobileNo("9617569669");
        user.setUserEmailAddress("sanket.asati@gmail.com");
        user.setUserpincode("481445");
        user.setUserAddress("balaghat");
        
        String jsonresult=mapToJson(user);
        ResponseEntity<UserData> postResponse = restTemplate.postForEntity(getRootUrl() + "/Add_user", jsonresult, UserData.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
        
     }

    
}
