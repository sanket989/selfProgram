package com.neosoft.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudWithSequrityOAuth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
