package com.neosoft.main.serviceI;

import java.util.List;

import com.neosoft.main.model.Student;



public interface StudentServiceI {
	public String SaveStudent(Student stu);
	public List<Student> ListOFStudent();
	public Student SingleResult(String studentId);

}
